﻿namespace WindowsFormsApplication3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxCalc = new System.Windows.Forms.GroupBox();
            this.lbResultado = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.txtRaio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButtonVolume = new System.Windows.Forms.RadioButton();
            this.radioButtonPerimetro = new System.Windows.Forms.RadioButton();
            this.radioButtonArea = new System.Windows.Forms.RadioButton();
            this.groupBoxCalc.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxCalc
            // 
            this.groupBoxCalc.Controls.Add(this.lbResultado);
            this.groupBoxCalc.Controls.Add(this.btnCalc);
            this.groupBoxCalc.Controls.Add(this.txtRaio);
            this.groupBoxCalc.Controls.Add(this.label1);
            this.groupBoxCalc.Controls.Add(this.radioButtonVolume);
            this.groupBoxCalc.Controls.Add(this.radioButtonPerimetro);
            this.groupBoxCalc.Controls.Add(this.radioButtonArea);
            this.groupBoxCalc.Location = new System.Drawing.Point(12, 12);
            this.groupBoxCalc.Name = "groupBoxCalc";
            this.groupBoxCalc.Size = new System.Drawing.Size(291, 297);
            this.groupBoxCalc.TabIndex = 1;
            this.groupBoxCalc.TabStop = false;
            this.groupBoxCalc.Text = "Calculo";
            // 
            // lbResultado
            // 
            this.lbResultado.BackColor = System.Drawing.Color.White;
            this.lbResultado.ForeColor = System.Drawing.Color.Black;
            this.lbResultado.Location = new System.Drawing.Point(16, 152);
            this.lbResultado.Name = "lbResultado";
            this.lbResultado.Size = new System.Drawing.Size(260, 64);
            this.lbResultado.TabIndex = 6;
            this.lbResultado.Text = "Resultado";
            this.lbResultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.White;
            this.btnCalc.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnCalc.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCalc.ForeColor = System.Drawing.Color.Black;
            this.btnCalc.Location = new System.Drawing.Point(3, 235);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(285, 59);
            this.btnCalc.TabIndex = 5;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtRaio
            // 
            this.txtRaio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRaio.Location = new System.Drawing.Point(94, 106);
            this.txtRaio.MaxLength = 10;
            this.txtRaio.Name = "txtRaio";
            this.txtRaio.Size = new System.Drawing.Size(134, 26);
            this.txtRaio.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Digite o raio:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // radioButtonVolume
            // 
            this.radioButtonVolume.AutoSize = true;
            this.radioButtonVolume.ForeColor = System.Drawing.Color.White;
            this.radioButtonVolume.Location = new System.Drawing.Point(7, 74);
            this.radioButtonVolume.Name = "radioButtonVolume";
            this.radioButtonVolume.Size = new System.Drawing.Size(98, 17);
            this.radioButtonVolume.TabIndex = 2;
            this.radioButtonVolume.Text = "Calculo Volume";
            this.radioButtonVolume.UseVisualStyleBackColor = true;
            // 
            // radioButtonPerimetro
            // 
            this.radioButtonPerimetro.AutoSize = true;
            this.radioButtonPerimetro.ForeColor = System.Drawing.Color.White;
            this.radioButtonPerimetro.Location = new System.Drawing.Point(7, 51);
            this.radioButtonPerimetro.Name = "radioButtonPerimetro";
            this.radioButtonPerimetro.Size = new System.Drawing.Size(107, 17);
            this.radioButtonPerimetro.TabIndex = 1;
            this.radioButtonPerimetro.Text = "Calculo Perimetro";
            this.radioButtonPerimetro.UseVisualStyleBackColor = true;
            // 
            // radioButtonArea
            // 
            this.radioButtonArea.AutoSize = true;
            this.radioButtonArea.Checked = true;
            this.radioButtonArea.ForeColor = System.Drawing.Color.White;
            this.radioButtonArea.Location = new System.Drawing.Point(7, 28);
            this.radioButtonArea.Name = "radioButtonArea";
            this.radioButtonArea.Size = new System.Drawing.Size(85, 17);
            this.radioButtonArea.TabIndex = 0;
            this.radioButtonArea.TabStop = true;
            this.radioButtonArea.Text = "Calculo Area";
            this.radioButtonArea.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(315, 321);
            this.Controls.Add(this.groupBoxCalc);
            this.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.groupBoxCalc.ResumeLayout(false);
            this.groupBoxCalc.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxCalc;
        private System.Windows.Forms.RadioButton radioButtonVolume;
        private System.Windows.Forms.RadioButton radioButtonPerimetro;
        private System.Windows.Forms.RadioButton radioButtonArea;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.TextBox txtRaio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbResultado;
    }
}

