﻿namespace prjCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbVisor = new System.Windows.Forms.Label();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btnSomar = new System.Windows.Forms.Button();
            this.btnSubtrair = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnPontoDecimal = new System.Windows.Forms.Button();
            this.btnInverterSinal = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btnBK = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnQuadrado = new System.Windows.Forms.Button();
            this.btnFracao = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.btnRaiz = new System.Windows.Forms.Button();
            this.btnTangente = new System.Windows.Forms.Button();
            this.btnCosseno = new System.Windows.Forms.Button();
            this.btnSeno = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnPI = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(23)))), ((int)(((byte)(31)))));
            this.panel1.Controls.Add(this.lbVisor);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(593, 100);
            this.panel1.TabIndex = 0;
            // 
            // lbVisor
            // 
            this.lbVisor.BackColor = System.Drawing.Color.White;
            this.lbVisor.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.lbVisor.ForeColor = System.Drawing.Color.Black;
            this.lbVisor.Location = new System.Drawing.Point(12, 29);
            this.lbVisor.Name = "lbVisor";
            this.lbVisor.Size = new System.Drawing.Size(561, 37);
            this.lbVisor.TabIndex = 0;
            this.lbVisor.Text = "0";
            this.lbVisor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn8.Location = new System.Drawing.Point(93, 184);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(77, 67);
            this.btn8.TabIndex = 1;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn0
            // 
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn0.Location = new System.Drawing.Point(93, 403);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(77, 67);
            this.btn0.TabIndex = 1;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn7.Location = new System.Drawing.Point(10, 184);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(77, 67);
            this.btn7.TabIndex = 1;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn9.Location = new System.Drawing.Point(176, 184);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(77, 67);
            this.btn9.TabIndex = 1;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn5.Location = new System.Drawing.Point(93, 257);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(77, 67);
            this.btn5.TabIndex = 1;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn6.Location = new System.Drawing.Point(176, 257);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(77, 67);
            this.btn6.TabIndex = 1;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn4.Location = new System.Drawing.Point(10, 257);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(77, 67);
            this.btn4.TabIndex = 1;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn2.Location = new System.Drawing.Point(93, 330);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(77, 67);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn3.Location = new System.Drawing.Point(176, 330);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(77, 67);
            this.btn3.TabIndex = 1;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btn1.Location = new System.Drawing.Point(10, 330);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(77, 67);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btnSomar
            // 
            this.btnSomar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnSomar.Location = new System.Drawing.Point(259, 330);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(77, 67);
            this.btnSomar.TabIndex = 1;
            this.btnSomar.Text = "+";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // btnSubtrair
            // 
            this.btnSubtrair.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnSubtrair.Location = new System.Drawing.Point(259, 257);
            this.btnSubtrair.Name = "btnSubtrair";
            this.btnSubtrair.Size = new System.Drawing.Size(77, 67);
            this.btnSubtrair.TabIndex = 1;
            this.btnSubtrair.Text = "-";
            this.btnSubtrair.UseVisualStyleBackColor = true;
            this.btnSubtrair.Click += new System.EventHandler(this.btnSubtrair_Click);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnMultiplicar.Location = new System.Drawing.Point(259, 184);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(77, 67);
            this.btnMultiplicar.TabIndex = 1;
            this.btnMultiplicar.Text = "×";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(167)))));
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnCalcular.Location = new System.Drawing.Point(259, 403);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(160, 67);
            this.btnCalcular.TabIndex = 1;
            this.btnCalcular.Text = "=";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnPontoDecimal
            // 
            this.btnPontoDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnPontoDecimal.Location = new System.Drawing.Point(176, 403);
            this.btnPontoDecimal.Name = "btnPontoDecimal";
            this.btnPontoDecimal.Size = new System.Drawing.Size(77, 67);
            this.btnPontoDecimal.TabIndex = 1;
            this.btnPontoDecimal.Text = ",";
            this.btnPontoDecimal.UseVisualStyleBackColor = true;
            this.btnPontoDecimal.Click += new System.EventHandler(this.btnPontoDecimal_Click);
            // 
            // btnInverterSinal
            // 
            this.btnInverterSinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnInverterSinal.Location = new System.Drawing.Point(10, 403);
            this.btnInverterSinal.Name = "btnInverterSinal";
            this.btnInverterSinal.Size = new System.Drawing.Size(77, 67);
            this.btnInverterSinal.TabIndex = 1;
            this.btnInverterSinal.Text = "±";
            this.btnInverterSinal.UseVisualStyleBackColor = true;
            this.btnInverterSinal.Click += new System.EventHandler(this.btnInverterSinal_Click);
            // 
            // btnCE
            // 
            this.btnCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnCE.Location = new System.Drawing.Point(93, 111);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(77, 67);
            this.btnCE.TabIndex = 1;
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = true;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnBK
            // 
            this.btnBK.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnBK.Location = new System.Drawing.Point(176, 111);
            this.btnBK.Name = "btnBK";
            this.btnBK.Size = new System.Drawing.Size(77, 67);
            this.btnBK.TabIndex = 1;
            this.btnBK.Text = "⌫";
            this.btnBK.UseVisualStyleBackColor = true;
            this.btnBK.Click += new System.EventHandler(this.btnBK_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnDividir.Location = new System.Drawing.Point(259, 111);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(77, 67);
            this.btnDividir.TabIndex = 1;
            this.btnDividir.Text = "÷";
            this.btnDividir.UseVisualStyleBackColor = true;
            this.btnDividir.Click += new System.EventHandler(this.btnDividir_Click);
            // 
            // btnC
            // 
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnC.Location = new System.Drawing.Point(10, 111);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(77, 67);
            this.btnC.TabIndex = 1;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnQuadrado
            // 
            this.btnQuadrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnQuadrado.Location = new System.Drawing.Point(342, 330);
            this.btnQuadrado.Name = "btnQuadrado";
            this.btnQuadrado.Size = new System.Drawing.Size(77, 67);
            this.btnQuadrado.TabIndex = 1;
            this.btnQuadrado.Text = "x²";
            this.btnQuadrado.UseVisualStyleBackColor = true;
            this.btnQuadrado.Click += new System.EventHandler(this.btnQuadrado_Click);
            // 
            // btnFracao
            // 
            this.btnFracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnFracao.Location = new System.Drawing.Point(342, 257);
            this.btnFracao.Name = "btnFracao";
            this.btnFracao.Size = new System.Drawing.Size(77, 67);
            this.btnFracao.TabIndex = 1;
            this.btnFracao.Text = "1/x";
            this.btnFracao.UseVisualStyleBackColor = true;
            this.btnFracao.Click += new System.EventHandler(this.btnFracao_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnPorcentagem.Location = new System.Drawing.Point(342, 184);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(77, 67);
            this.btnPorcentagem.TabIndex = 1;
            this.btnPorcentagem.Text = "%";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // btnRaiz
            // 
            this.btnRaiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnRaiz.Location = new System.Drawing.Point(342, 111);
            this.btnRaiz.Name = "btnRaiz";
            this.btnRaiz.Size = new System.Drawing.Size(77, 67);
            this.btnRaiz.TabIndex = 1;
            this.btnRaiz.Text = "√";
            this.btnRaiz.UseVisualStyleBackColor = true;
            this.btnRaiz.Click += new System.EventHandler(this.btnRaiz_Click);
            // 
            // btnTangente
            // 
            this.btnTangente.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.btnTangente.Location = new System.Drawing.Point(425, 257);
            this.btnTangente.Name = "btnTangente";
            this.btnTangente.Size = new System.Drawing.Size(159, 67);
            this.btnTangente.TabIndex = 1;
            this.btnTangente.Text = "TANGENTE";
            this.btnTangente.UseVisualStyleBackColor = true;
            this.btnTangente.Click += new System.EventHandler(this.btnTangente_Click);
            // 
            // btnCosseno
            // 
            this.btnCosseno.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnCosseno.Location = new System.Drawing.Point(425, 184);
            this.btnCosseno.Name = "btnCosseno";
            this.btnCosseno.Size = new System.Drawing.Size(159, 67);
            this.btnCosseno.TabIndex = 1;
            this.btnCosseno.Text = "COSSENO";
            this.btnCosseno.UseVisualStyleBackColor = true;
            this.btnCosseno.Click += new System.EventHandler(this.btnCosseno_Click);
            // 
            // btnSeno
            // 
            this.btnSeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnSeno.Location = new System.Drawing.Point(425, 111);
            this.btnSeno.Name = "btnSeno";
            this.btnSeno.Size = new System.Drawing.Size(159, 67);
            this.btnSeno.TabIndex = 1;
            this.btnSeno.Text = "SENO";
            this.btnSeno.UseVisualStyleBackColor = true;
            this.btnSeno.Click += new System.EventHandler(this.btnSeno_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.button2.Location = new System.Drawing.Point(425, 403);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(159, 67);
            this.button2.TabIndex = 1;
            this.button2.Text = "LOG";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btnPI
            // 
            this.btnPI.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnPI.Location = new System.Drawing.Point(425, 330);
            this.btnPI.Name = "btnPI";
            this.btnPI.Size = new System.Drawing.Size(77, 67);
            this.btnPI.TabIndex = 1;
            this.btnPI.Text = "PI";
            this.btnPI.UseVisualStyleBackColor = true;
            this.btnPI.Click += new System.EventHandler(this.btnPI_Click);
            // 
            // btnE
            // 
            this.btnE.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.btnE.Location = new System.Drawing.Point(504, 330);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(77, 67);
            this.btnE.TabIndex = 1;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = true;
            this.btnE.Click += new System.EventHandler(this.btnE_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(52)))), ((int)(((byte)(89)))));
            this.ClientSize = new System.Drawing.Size(593, 477);
            this.Controls.Add(this.btnPontoDecimal);
            this.Controls.Add(this.btnInverterSinal);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnSeno);
            this.Controls.Add(this.btnRaiz);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnCosseno);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnTangente);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnFracao);
            this.Controls.Add(this.btnSubtrair);
            this.Controls.Add(this.btnE);
            this.Controls.Add(this.btnPI);
            this.Controls.Add(this.btnQuadrado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btnBK);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CALCULADORA VERSAO 1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbVisor;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Button btnSubtrair;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnPontoDecimal;
        private System.Windows.Forms.Button btnInverterSinal;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btnBK;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnQuadrado;
        private System.Windows.Forms.Button btnFracao;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Button btnRaiz;
        private System.Windows.Forms.Button btnTangente;
        private System.Windows.Forms.Button btnCosseno;
        private System.Windows.Forms.Button btnSeno;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnPI;
        private System.Windows.Forms.Button btnE;
    }
}

